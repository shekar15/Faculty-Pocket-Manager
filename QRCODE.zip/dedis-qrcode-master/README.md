# dedis-qrcode

A simple QR Code scanner implemented with phonegap.
